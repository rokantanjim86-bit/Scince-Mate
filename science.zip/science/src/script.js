function attemptLogin() {
    const username = document.getElementById('username_input').value.trim();
    const password = document.getElementById('password_input').value.trim();
    const message = document.getElementById('login-message');

    // ডেমো ইউজারনেম ও পাসওয়ার্ড (বাস্তব অ্যাপে, এটি সার্ভার-ভিত্তিক হওয়া আবশ্যক!)
    const VALID_USER = "science";
    const VALID_PASS = "mate123";

    if (username === VALID_USER && password === VALID_PASS) {
        // Successful Login
        
        // লগইন স্ক্রিন লুকিয়ে মূল কন্টেন্ট দেখান
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('main-app-content').style.display = 'block';
        
        // যদি আপনার অ্যাপের অন্য কোনো ইনিশিয়ালাইজেশন ফাংশন থাকে, সেটা এখানে কল করুন (যেমন: displayDailyTip();)
        // window.onload ফাংশনে আর কিছু না রেখে সেটিকে এখানে কল করা ভালো।
        
        message.innerText = "";
    } else {
        // Failed Login
        message.innerText = "Invalid Username or Password. Please try again.";
    }
}

// নিশ্চিত করুন যে অ্যাপ লোড হওয়ার সাথে সাথেই মূল কন্টেন্টগুলো Hide করা আছে 
document.addEventListener('DOMContentLoaded', () => {
    // লগইন স্ক্রিনটি প্রথমে দেখাতে main-app-content আড়াল করা
    document.getElementById('main-app-content').style.display = 'none';
});

// আপনার app.js ফাইলের বাকি কোডগুলো এখানে থাকবে
// ...